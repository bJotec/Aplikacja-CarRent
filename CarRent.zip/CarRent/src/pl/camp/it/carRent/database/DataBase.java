package pl.camp.it.carRent.database;
import pl.camp.it.carRent.model.Car;

public class DataBase {

  private Car[] cars = new Car[5];

    public DataBase() {

        this.cars[0] = new Car("BMW", "2", 2010, "KR1");
        this.cars[1] = new Car("Mercedes", "C", 2012, "KR2");
        this.cars[2] = new Car("Toyota", "Corolla", 2007, "KR3");
        this.cars[3] = new Car("Mazda", "3", 2016, "KR4");
        this.cars[4] = new Car("Porsche", "Carrera", 2017, "KR5");
    }


        public Car findNotRentCarByPlate(String plate) {               // metoda opis :    co metoda zwraca - nazwe metody - przyjmuje parametry
            Car car = this.findCarByPlate(plate);
            if(car == null || car.isRent()) {
                return null;
            } else {
                return car;
            }
        }

        public Car findRentCarByPlate(String plate) {
            Car car = this.findCarByPlate(plate);
            if(car == null || !car.isRent()) {
                return null;
            } else {
                return car;
            }
        }

        private Car findCarByPlate(String plate) {
            for(Car car : this.cars) {
                if(car.getPlate().equals(plate)) {
                    return car;
                }
            }
            return null;
        }

        public Car[] getCars() {
            return cars;
        }
    }
