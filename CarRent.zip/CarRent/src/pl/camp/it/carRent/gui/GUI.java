package pl.camp.it.carRent.gui;
import pl.camp.it.carRent.model.Car;

public class GUI {

   public void showMenu() {
        System.out.println("1. Lista aut");
        System.out.println("2. Wypozycz auto");
        System.out.println("3. Wyjdz");
        System.out.println("4. Oddaj auto");
    }

    public void printCar(Car car) {

        System.out.println(car.getBrand()+ " " + car.getModel() + " rok: " + car.getYear() + " numer rejestracyjny: " + car.getPlate());
        if (car.isRent()) {
            System.out.print(" status:  wypożyczony");
        } else {
            System.out.print(" status: wolny");
        }
        System.out.println();
    }
}
